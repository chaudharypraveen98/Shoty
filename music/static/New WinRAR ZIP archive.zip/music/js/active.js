var overlay = document.getElementById("loader");

window.addEventListener('load', function(){
  overlay.style.display = 'none';
})